from os import listdir
import os
import sys
import datetime
import asyncio
from asyncio import sleep

sys.path.append(os.path.abspath('settings'))
from global_sets import * # Импорт основных настроек
from config import settings
from config import COGS_DIR

sys.path.append(os.path.abspath('tools'))
from information import * # комманды с информацией
from entertainment import * # комманды для развлечений
from moderation import * # комманды для модерации
from shikimori import * # комманды для парса шики
from notifications import * # Уведомление
#from server import * # команда serverinfo
#from utils import default
#from utils.data import Bot
from Econimic import * # Экономика

from async_timeout import timeout
from discord.ext import commands

# Убираем вывод лишних логов с библиотеки youtube_dl
youtube_dl.utils.bug_reports_message = lambda: ''

# Объявляем событие начало работы бота
#@client.event
#async def on_ready():
#    print (f"Working as {settings['NAME BOT']}")
#    await client.change_presence(status=discord.Status.online, activity=discord.Streaming(name=f' ◟︎5 серверов◝︎', url='https://www.twitch.tv/unknowpage'))

@client.event
async def on_ready():
    cursor.execute("""CREATE TABLE IF NOT EXISTS users (
        name TEXT,
        id INT,
        cash BIGINT,
        rep INT,
        lvl INT,
        server_id INT
    )""")

    cursor.execute("""CREATE TABLE IF NOT EXISTS shop (
        role_id INT,
        id INT,
        cost BIGINT
    )""")

    for guild in client.guilds:
        for member in guild.members:
            if cursor.execute(f"SELECT id FROM users WHERE id = {member.id}").fetchone() is None:
                cursor.execute(f"INSERT INTO users VALUES ('{member}', {member.id}, 0, 0, 1, {guild.id})")
            else:
                pass

    connection.commit()
    print (f"|Working as {settings['NAME BOT']} \n|User: B1eR\n|ID: #4936\n|Time: LifeTime\n|Ram: 3500mb\n|Plugin: Premium,dll,dev,fastdll,modhub,database\n|DataBase: server.db\n|Dev: JestBots.B1eR\n\n░██████╗████████╗░█████╗░██████╗░████████╗\n██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝\n╚█████╗░░░░██║░░░███████║██████╔╝░░░██║░░░\n░╚═══██╗░░░██║░░░██╔══██║██╔══██╗░░░██║░░░\n██████╔╝░░░██║░░░██║░░██║██║░░██║░░░██║░░░\n╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░\n\nCommands/Logs:\n")
    while True:
        await client.change_presence(activity=discord.Streaming(name=f'⠀◟︎ {len(client.guilds)}⠀Серверов◝︎', url='https://www.twitch.tv/unknowpage'))
        await asyncio.sleep(3)
        await client.change_presence(activity=discord.Streaming(name=f'⠀◟︎{len(client.users)} пользователей◝︎', url='https://www.twitch.tv/unknowpage'))
        await asyncio.sleep(3)

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send(embed=discord.Embed(
            description=f'**◸︎**⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀◟︎**{ctx.author.name}**◝︎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀**◹︎**\n⠀⠀⠀⠀⠀⠀⠀данной команды не существует! \n⠀⠀⠀⠀⠀⠀⠀Воспользуйтесь командой !**help**\n**◺︎**⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⠀⠀⠀**◿︎**',
            color=discord.Color.red()))


if __name__ == '__main__':
    for folder in listdir(COGS_DIR):
        if folder.endswith('.py'):
            client.load_extension(f'cogs.{folder[:-3]}')

client.run (settings['TOKEN']) # Запуск бота