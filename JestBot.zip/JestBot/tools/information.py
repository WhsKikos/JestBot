import os
import sys
import datetime
from discord_components import DiscordComponents, Button, ButtonStyle
from translate import Translator
from discord.abc import GuildChannel

sys.path.append(os.path.abspath('../settings'))
from global_sets import *
from async_timeout import timeout
from discord.ext import commands

# Help command
intents = discord.Intents.all()
# Удаляем изначальную команду help
client.remove_command('help')

@client.command(aliases = ['Help', 'help', 'HELP', 'hELP', 'хелп', 'Хелп', 'ХЕЛП', 'хЕЛП'])
async def __help (ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '**Доступные команды**', description = '', colour = discord.Color.magenta() )
    
        emb.set_author(name = ctx.author.name, icon_url = ctx.author.avatar_url)

        emb.add_field( name = '◟︎Информация◝︎', value = f'`{prefix}help` `{prefix}ping` `{prefix}list` `{prefix}anime` `{prefix}userinfo` `{prefix}statserver` `{prefix}перевод`', inline=False)
        emb.add_field( name = '◟︎Развлечение◝︎', value = f'`{prefix}joke 1-18` `{prefix}обнять`', inline=False)
        emb.add_field( name = '◟︎Модерации◝︎', value = f' `{prefix}clear` `{prefix}kick` `{prefix}ban`', inline=False)
        emb.add_field( name = '◟Экономика◝︎', value = f' `{prefix}balance` `{prefix}agivemoney` `{prefix}atakemoney` `{prefix}add-shop` `{prefix}remove-shop` `{prefix}shop` `{prefix}buy-role` `{prefix}+rep` `{prefix}leaderboard`', inline=False)

        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/goescat/macaron/128/terminator-icon.png")
        await ctx.send ( embed = emb)

    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/help] Справка по командам была выведена | {prefix}help ')



# Ping
@client.command(aliases = ['Ping', 'PING', 'ping', 'пинг', 'Пинг'])
async def __ping(ctx):
    if (right_channel(ctx)):
        ping = client.ws.latency # Получаем пинг клиента для вывода
        message = await ctx.send('Погоди, мужик. . .') # Изначальное сообщение
        await message.edit(content = f'Пинг сервера: {ping_emoji} `{ping * 1000:.0f}ms`') # Редактирование сообщения
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")
        
    print(f'[Logs/Ping] Пинг сервера был выведен | {prefix}ping') # Информация в консоль
    print(f'[Logs/Ping] На данный момент пинг == {ping * 1000:.0f}ms | {prefix}ping') # Вывод пинга в консоль



# Достопромечательности
@client.command(aliases = ['список', 'list', 'spisok', 'Список', 'List', 'Spisok'])
async def __spisok(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = 'Достопримечательности бота:', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Premium:', value = f' `{prefix}store` ', inline=False)
        emb.add_field( name = 'Мой хозяин', value = f'`HelenTaylor#5319` ', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/graphicloads/flat-finance/128/person-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] Достопримечательности был выведены | {prefix}list') # Информация в консоль

#info
@client.command()
async def info(ctx):
    msg = await ctx.send(
        embed = discord.Embed(title = '<:3174partnerseagull:963503148725575760> | Выберите действие', timestamp = ctx.message.created_at),
        components = [
            Button(style = ButtonStyle.URL, label = 'Добавить бота на сервер', url='https://dsc.gg/jestinvite'),
            Button(style = ButtonStyle.URL, label = 'Зайти на сервер разработчика', url='https://dsc.gg/support_gerise'),
        ])

@client.command()
async def перевод(ctx, *, text):
    translator = Translator(to_lang='ru')
    translation = translator.translate(text)
    embed = discord.Embed(colour = discord.Color.random(), title = 'Переводчик', description = translation)
    await ctx.send(embed=embed)

@client.command()
async def userinfo(ctx,member:discord.Member = None, guild: discord.Guild = None):
    await ctx.message.delete()
    if member == None:
        emb = discord.Embed(title="◟︎Информация о пользователе◝︎", color=ctx.message.author.color)
        emb.add_field(name="Имя:", value=ctx.message.author.display_name,inline=False)
        emb.add_field(name="Айди пользователя:", value=ctx.message.author.id,inline=False)
        t = ctx.message.author.status
        if t == discord.Status.online:
            d = " В сети"

        t = ctx.message.author.status
        if t == discord.Status.offline:
            d = "⚪ Не в сети"

        t = ctx.message.author.status
        if t == discord.Status.idle:
            d = " Не активен"

        t = ctx.message.author.status
        if t == discord.Status.dnd:
            d = " Не беспокоить"

        emb.add_field(name="Активность:", value=d,inline=False)
        emb.add_field(name="Статус:", value=ctx.message.author.activity,inline=False)
        emb.add_field(name="Роль на сервере:", value=f"{ctx.message.author.top_role.mention}",inline=False)
        emb.add_field(name="Акаунт был создан:", value=ctx.message.author.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"),inline=False)
        emb.set_thumbnail(url=ctx.message.author.avatar_url)
        await ctx.send(embed = emb)
    else:
        emb = discord.Embed(title="◟︎Информация о пользователе◝︎", color=member.color)
        emb.add_field(name="Имя:", value=member.display_name,inline=False)
        emb.add_field(name="Айди пользователя:", value=member.id,inline=False)
        t = member.status
        if t == discord.Status.online:
            d = " В сети"

        t = member.status
        if t == discord.Status.offline:
            d = "⚪ Не в сети"

        t = member.status
        if t == discord.Status.idle:
            d = " Не активен"

        t = member.status
        if t == discord.Status.dnd:
            d = " Не беспокоить"
        emb.add_field(name="Активность:", value=d,inline=False)
        emb.add_field(name="Статус:", value=member.activity,inline=False)
        emb.add_field(name="Роль на сервере:", value=f"{member.top_role.mention}",inline=False)
        emb.add_field(name="Акаунт был создан:", value=member.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"),inline=False)
        await ctx.send(embed = emb)

# Премиум
@client.command(aliases = ['магазин', 'stor', 'stores', 'Магазин', 'store', 'Store'])
async def __store(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = 'Достопримечательности бота:', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Цена', value = f' `30 рублей` ', inline=False)
        emb.add_field( name = 'Qiwi', value = f'`+79831797341` (Обязательно написать свой discord \nНаписать в личку то что купил + чек - HelenTaylor#5319 ) ', inline=False)
        emb.add_field( name = 'Статус', value = f' `Недоступно` ', inline=False)
        emb.add_field( name = 'Описание', value = f' `При оплате вы получаете:`\nВерсию Premium \nПопадаете в лист `userpremium`\nВремя: `LifeTime`\nModHub', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/graphicloads/flat-finance/128/person-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] Достопримечательности был выведены | {prefix}list') # Информация в консоль

# Топ премиум юзеры
@client.command(aliases = ['userpremium', 'Premiumuser', 'PremiumUser', 'Pu', 'pu', 'pU'])
async def __userpremium(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = 'Пользователи которые купили ``премиум`` версию:', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Топ-1', value = f'`Нету`', inline=False)
        emb.add_field( name = 'Топ-14', value = f'Нету\nНету\nНету\nНету\nНету\nНету\nНету\nНету\nНету\nНету\nНету\nНету\nНету\nНету ', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/graphicloads/flat-finance/128/person-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] Достопримечательности был выведены | {prefix}list') # Информация в консоль

# statserver
@client.command(aliases = ['statserver', 'StatServer', 'ss', 'Ss', 'sS', 'Server'])
async def __statserver(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:2280servers:963503148385857616> | Статус **сервера** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Shard-1', value = f'`*Ошибка*` серверов в базе', inline=False)
        emb.add_field( name = 'Shard-2', value = f'`*Ошибка*` серверов в базе', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/papirus-team/papirus-devices/96/network-server-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] Достопримечательности был выведены | {prefix}list') # Информация в консоль

@client.command(pass_context=True)
async def serverers(ctx):
    await ctx.send("Количество серверов, на которых я есть: " + str(len(client.guilds)) + " кол-во серверов")


# modhub
@client.command(aliases = ['modhub', 'ModHub', 'mh', 'Mh', 'mH', 'Mods'])
async def __modhub(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:3121discordearlysupporter:963503148478115900> | Статус **modhub** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Mods-1', value = f'`*Ошибка*` модов в базе', inline=False)
        emb.add_field( name = 'Mods-2', value = f'`*Ошибка*` модов в базе', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/paomedia/small-n-flat/96/file-exe-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] modhub был выведены | {prefix}modhub') # Информация в консоль

# modhub-help
@client.command(aliases = ['modhub-help', 'ModHub-Help', 'mh-h', 'Mh-H', 'mH-h', 'Mods-help'])
async def __modhubhelp(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:3121discordearlysupporter:963503148478115900> | **modhub** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Помочь по modhub', value = f'Если хотите добавить свою команду >> `!info`', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/paomedia/small-n-flat/96/file-exe-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] modhub был выведены | {prefix}modhub') # Информация в консоль

# GitHub
@client.command(aliases = ['github', 'GitHub', 'gh', 'Gh', 'gH', 'Git'])
async def __github(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:github:964909909038751844> | **GitHub** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'GitHub', value = f'`https://github.com/WhsKikos`', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/papirus-team/papirus-apps/96/git-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] modhub был выведены | {prefix}modhub') # Информация в консоль

# news
@client.command(aliases = ['news', 'News', 'nw', 'Nw', 'nW'])
async def __new(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:3149blurplerules:963503148452970566> | **Новости** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'Новости', value = f'`Бот вышел в комьюнити серверов!`', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/martz90/hex/96/radio-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] modhub был выведены | {prefix}modhub') # Информация в консоль

# system
@client.command(aliases = ['system', 'System', 'st', 'St', 'sT'])
async def __system(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:1520blurplesettings:963503147567943681> | **System** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'System', value = f'`System: 1.0`\nRam: 3500mb\nPlugin: dll,fastdll,modhub,database\nDataBase: server.db\nDev: JestBots.B1eR', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/cornmanthe3rd/metronome/96/System-settings-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] modhub был выведены | {prefix}modhub') # Информация в консоль

# bot
@client.command(aliases = ['bot', 'Bot', 'bt', 'Bt', 'bT'])
async def __bot(ctx):
    if (right_channel(ctx)):
        emb = discord.Embed( title = '<:1646discordboten:963503148029341786> | **Информация** бота', description = '', colour = discord.Color.magenta() )  
        emb.add_field( name = 'System', value = f'`Версия: beta`\n**Время использование**: LifeTime\n**Память**: 3500**MB**\n**Плагины**: dll,fastdll,modhub,database\n**ДатаБаза**: server.db\n**Разраб**: JestBots.B1eR', inline=False)
        emb.set_thumbnail(url = "https://icons.iconarchive.com/icons/cornmanthe3rd/metronome/96/System-settings-icon.png") # иконка справа
        await ctx.send ( embed = emb)
        # Отправляет сообщение и так же преобразует emb в embed
    else:
        await ctx.send("Этот канал не предназначен для меня, используйте канал `JestBot`, пожалуйста!")

    print(f'[Logs/list] modhub был выведены | {prefix}modhub') # Информация в консоль