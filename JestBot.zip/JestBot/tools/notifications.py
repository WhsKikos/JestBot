import os
import sys

from get_file import rdm

sys.path.append(os.path.abspath('../settings'))
from global_sets import *
from async_timeout import timeout
from discord.ext import commands

@client.command()
async def bc(ctx: commands.Context, message: str):
    for member in ctx.guild.members:
        try:
            await member.send(f'**◜**⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀◟︎**{member.mention}**◝︎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n|⠀⠀⠀⠀⠀⠀⠀Новое обьявление от бота **JestBot** \n|⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{message}\n◟⠀⠀⠀⠀⠀⠀⠀Присоединяйтесь!')
        except:
            pass