import os
import sys

sys.path.append(os.path.abspath('../settings'))
from global_sets import *
from async_timeout import timeout
from discord.ext import commands

# Есть ли права администратора у пользователя
def is_admin(ctx):
    return ctx.message.author.guild_permissions.administrator

# Может ли пользователь удалять или изменять сообщения
def manage_messages(ctx):
    return is_admin or ctx.message.author.guild_permissions.manage_messages


# Очистка сообщений
#clear
@client.command(aliases = ['Clear', 'CLEAR', 'cLEAR', 'clear', 'Очистить', 'ОЧИСТИТЬ', 'оЧИСТИТЬ', 'очистить', 'Клс', 'КЛС', 'кЛС', 'клс' 'cls' 'Cls' 'CLS' 'cLs' 'cLS'])
async def __clear(ctx, amount=None):
    await ctx.message.delete()
    await ctx.channel.purge(limit=int(amount))
    emb = discord.Embed(title='<a:1446greenverify:963503148717199410> | Сообщение успешно удалены!', color=discord.Color.magenta())
    await ctx.send(embed=emb)

#Kick
@client.command(aliases = ['кик', 'Кик', 'кИК', 'КИК', 'Kick', 'kICK', 'KICK', 'kick'])
@commands.has_permissions ( administrator = True ) # Команда только для пользователей имеющих роль с правами "Администратор"
async def __kick(ctx, member: discord.Member, *, reason = None): # Асинхронная функция __kick(ctx, member: discord.Member, *, reason = None)
    #Аргументы: ctx - отправка сообщения с помощью команды (Обязательно)
    #Аргументы: member: discord.Member - "member" ----- может быть любой текст, но для удобства использую member (Discord.Member - для получения id указанного пользователя)
    #Аргументы: * - предыдущий аргумент необходим
    #Аргументы: reason = None - "reason" ----- может быть любой текст, но для удобства использовал reason, "None" - значение по умолчанию
    await ctx.message.add_reaction('✅') # Добавляет реакцию к сообщению с командой
    await member.kick( reason = reason ) # Кикнуть пользователя по причине (Преобразует причину бота в причину дискорда)
    emb = discord.Embed( title = 'kick', description = f'Пользователь {member}  был кикнут по причине { reason } ', colour = discord.Color.magenta() )
    emb.set_author( name = client.user.name )
    emb.set_footer( text = ctx.author.name, icon_url = ctx.author.avatar_url )
    emb.set_thumbnail(url = client.user.avatar_url)

    await ctx.send( embed = emb )

    print(f'[Logs:moderation] Пользователь {member} был кикнут по причине {reason} | {prefix}kick ')

@__kick.error
async def kick_error(ctx, goodbye):
	if isinstance ( goodbye, commands.MissingRequiredArgument):
		emb = discord.Embed( title = f'**Команда "{prefix}кик"**', description = f'Изгоняет указаного участника с сервера с возможностью возвращения ', colour = discord.Color.magenta() )
		emb.set_author(name = ctx.author.name, icon_url = ctx.author.avatar_url)
		emb.add_field( name = 'Использование', value = "!кик <@⁣Участник | ID>", inline=False)
		emb.add_field( name = 'Пример', value = "`!кик @⁣Участник`\n┗ Кикнет указаного участника.", inline=False)
		emb.set_thumbnail(url = client.user.avatar_url)
		emb.set_footer( icon_url = client.user.avatar_url, text = f"{settings['OWNER NAME']} © Copyright 2022 | Все права защищены"   )
		await ctx.send ( embed = emb)
		print(f"[Logs:error] Необходимо указать участника | {prefix}kick")

	if isinstance (goodbye, commands.MissingPermissions):
		emb = discord.Embed( title = f'**Команда "{prefix}кик"**', description = f'Изгоняет указаного участника с сервера с возможностью возвращения ', colour = discord.Color.magenta() )
		emb.set_author(name = ctx.author.name, icon_url = ctx.author.avatar_url)
		emb.add_field( name = 'ОШИБКА!', value = "У вас недостаточно прав!", inline=False)
		emb.set_thumbnail(url = client.user.avatar_url)
		emb.set_footer( icon_url = client.user.avatar_url, text = f"{settings['OWNER NAME']} © Copyright 2022 | Все права защищены"   )
		await ctx.send ( embed = emb)
		print(f"[Logs:Error] [Ошибка доступа] Пользователь [{ctx.author}] попытался кикнуть | {prefix}kick")

#ban
@client.command(aliases = ['бан', 'Бан', 'бАН', 'БАН', 'ban', 'bAN', 'BAN', 'Ban'])
@commands.has_permissions ( administrator = True ) # Команда только для пользователей имеющих роль с правами "Администратор"
async def __ban(ctx, member: discord.Member, *, reason = None): # Асинхронная функция __ban(ctx, member: discord.Member, *, reason = None)
    #Аргументы: ctx - отправка сообщения с помощью команды (Обязательно)
    #Аргументы: member: discord.Member - "member" ----- может быть любой текст, но для удобства использую member (Discord.Member - для получения id указанного пользователя)
    #Аргументы: * - предыдущий аргумент необходим
    #Аргументы: reason = None - "reason" ----- может быть любой текст, но для удобства использовал reason, "None" - значение по умолчанию
    await ctx.message.add_reaction('✅') # Добавляет реакцию к сообщению с командой
    await member.ban( reason = reason ) # забанить пользователя по причине (Преобразует причину бота в причину дискорда)
    emb = discord.Embed( title = 'ban', description = f'Пользователь {member}  был забанен по причине { reason } ', colour = discord.Color.magenta() )
    emb.set_author( name = client.user.name )
    emb.set_footer( text = ctx.author.name, icon_url = ctx.author.avatar_url )
    emb.set_thumbnail(url = client.user.avatar_url)

    await ctx.send( embed = emb )

    print(f'[Logs:moderation] Пользователь {member} был забанен по причине {reason} | {prefix}ban ')

@__ban.error
async def ban_error(ctx, goodbye):
    if isinstance ( goodbye, commands.MissingRequiredArgument):
        emb = discord.Embed( title = f'**Команда "{prefix}бан"**', description = f'Изгоняет указаного участника с сервера с невозможностью возвращения ', colour = discord.Color.magenta() )
        emb.set_author(name = ctx.author.name, icon_url = ctx.author.avatar_url)
        emb.add_field( name = 'Использование', value = "!бан <@⁣Участник | ID>", inline=False)
        emb.add_field( name = 'Пример', value = "`!бан @⁣Участник`\n┗ Забанит указаного участника.", inline=False)
        emb.set_thumbnail(url = client.user.avatar_url)
        emb.set_footer( icon_url = client.user.avatar_url, text = f"{settings['OWNER NAME']} © Copyright 2022 | Все права защищены"   )
        await ctx.send ( embed = emb)
        print(f"[Logs:error] Необходимо указать участника | {prefix}ban")

    if isinstance (goodbye, commands.MissingPermissions):
        emb = discord.Embed( title = f'**Команда "{prefix}бан"**', description = f'Изгоняет указаного участника с сервера с невозможностью возвращения ', colour = discord.Color.magenta() )
        emb.set_author(name = ctx.author.name, icon_url = ctx.author.avatar_url)
        print(f"[Logs:Error] [Ошибка доступа] Пользователь [{ctx.author}] попытался забанить | {prefix}ban")
        emb.add_field( name = 'ОШИБКА!', value = "У вас недостаточно прав!", inline=False)
        emb.set_thumbnail(url = client.user.avatar_url)
        emb.set_footer( icon_url = client.user.avatar_url, text = f"{settings['OWNER NAME']} © Copyright 2022 | Все права защищены"   )
        await ctx.send ( embed = emb)