import discord # Импорт главной библиотеки discord.py
import json # Работа с файлами
import requests # Работа с запросами
import asyncio # Работа с музыкой
import youtube_dl # Скачивание музыки с yt
import functools # Вспомогательный функционал
import itertools # Вспомогательный функционал
import math # Математика
import random # Рандом
import os
from discord.abc import GuildChannel

from discord.ext import commands # Импорт из библиотеки discord.py библиотеки commands
from config import settings # Импорт из файла config.py настроек

# Чтение файла env.json с настройками
with open("files/env.json", "r") as env:
    ENV = json.load(env)

# Получение пути из env.json
ECCHI_FOLDER = ENV["ecchi_folder"]
LEGS_FOLDER = ENV["legs_folder"]

# Получение префикса комманд из настроек
prefix = settings['PREFIX']

intents = discord.Intents.all()
# Определяем переменную для работы с ботом
client = commands.Bot(command_prefix = settings['PREFIX'], help_command=None, intents=intents)

# Убираем вывод лишних логов с библиотеки youtube_dl
youtube_dl.utils.bug_reports_message = lambda: ''

# Парсинг контента определенного сайта
def get_html(url):
    r = requests.get(url)
    return (r.text.replace('{"content":"', '').replace('"}', ''))

# Проверка правильности канала
def right_channel(ctx):
    if (
        str(ctx.message.channel.name) == "jestBot-channel" and (
        str(ctx.message.channel.type) == "private" or
        ctx.message.channel.is_nsfw())
    ):
        return True
    return True