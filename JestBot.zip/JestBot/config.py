import os

settings = {
    'TOKEN': 'OTYxMjY3NTg5MTE4NTc0NjQy.Yk2gNA.AYBGm6Crp5qkARJcQx0wO23eD5M', # Ваш токен
    'NAME BOT': 'JestBot', # Используемое имя бота
    'ID': '957968956075958293', # Client ID
    'PREFIX': '!', # Префикс комманд
	'OWNER':'HelenTaylor#5319',    
	'OWNER NAME':'HelenTaylor',
    'owners': 'HelenTaylor'
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
COGS_DIR = os.path.join(BASE_DIR, 'cogs')